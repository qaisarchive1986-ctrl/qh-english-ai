# QH English AI 2.0 — Real Backend

Backend آماده برای اتصال به GitHub Pages و استقرار روی Vercel.

## Endpoints
- `GET /api/health`
- `POST /api/chat`
- `POST /api/lesson`
- `POST /api/transcribe`
- `POST /api/tts`

## Deploy
1. این پروژه را در GitHub با نام `qh-english-ai-backend` بسازید.
2. فایل‌های این ZIP را در root repository آپلود کنید.
3. Repository را در Vercel Import کنید.
4. Environment Variables:
   - `OPENAI_API_KEY` = کلید API
   - `OPENAI_MODEL` = `gpt-5` یا مدل موجود در حساب شما
   - `ALLOWED_ORIGIN` = آدرس دقیق GitHub Pages شما، یا موقتاً `*`
5. Deploy کنید.
6. تست کنید:
   `https://YOUR-DOMAIN.vercel.app/api/health`

## امنیت
کلید API فقط در Environment Variables سمت سرور است و در frontend قرار نمی‌گیرد.
