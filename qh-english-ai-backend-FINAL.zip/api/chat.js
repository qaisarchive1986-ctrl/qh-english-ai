import OpenAI from "openai";
import { cors } from "./_cors.js";

export default async function handler(req,res){
  if(cors(req,res)) return;
  if(req.method!=="POST") return res.status(405).json({error:"POST only"});
  try{
    const {message,level="A1",history=[]}=req.body||{};
    if(typeof message!=="string"||!message.trim()) return res.status(400).json({error:"message is required"});
    if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const system=`You are QH English AI 2.0, a professional English teacher for Dari-speaking Afghan learners.
Current level: ${level}. Teach from zero to C2.
Explain difficult grammar and corrections in Dari (Persian script), but keep English examples in English.
Be accurate, encouraging and concise. Never claim to hear audio unless a transcript is supplied.`;
    const input=[{role:"system",content:system},...(Array.isArray(history)?history.slice(-10):[]),{role:"user",content:message.trim()}];
    const r=await client.responses.create({model:process.env.OPENAI_MODEL||"gpt-5",input});
    res.status(200).json({reply:r.output_text||"پاسخی دریافت نشد."});
  }catch(e){console.error(e);res.status(500).json({error:"AI request failed",detail:e.message})}
}
