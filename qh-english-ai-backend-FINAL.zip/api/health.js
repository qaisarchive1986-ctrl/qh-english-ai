export default async function handler(req,res){
  res.status(200).json({ok:true,service:"QH English AI 2.0 Backend",version:"2.0.0",runtime:process.version});
}
