import OpenAI from "openai";
import { cors } from "./_cors.js";

export default async function handler(req,res){
  if(cors(req,res)) return;
  if(req.method!=="POST") return res.status(405).json({error:"POST only"});
  try{
    const {audio,mime="audio/webm"}=req.body||{};
    if(!audio) return res.status(400).json({error:"audio is required"});
    if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});
    const bytes=Buffer.from(audio,"base64");
    const file=new File([bytes],"speech.webm",{type:mime});
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const r=await client.audio.transcriptions.create({file,model:"gpt-4o-mini-transcribe"});
    res.json({text:r.text||""});
  }catch(e){console.error(e);res.status(500).json({error:"Transcription failed",detail:e.message})}
}
