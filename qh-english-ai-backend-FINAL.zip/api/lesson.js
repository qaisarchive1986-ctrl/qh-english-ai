import OpenAI from "openai";
import { cors } from "./_cors.js";

export default async function handler(req,res){
  if(cors(req,res)) return;
  if(req.method!=="POST") return res.status(405).json({error:"POST only"});
  try{
    const {level="A1",minutes=30,weaknesses=[]}=req.body||{};
    if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});
    const m=Math.min(60,Math.max(15,Number(minutes)||30));
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const prompt=`Create a personalized daily English lesson for a Dari-speaking learner.
Level: ${level}; available time: ${m} minutes; known weaknesses: ${JSON.stringify(weaknesses)}.
Return ONLY valid JSON. Schema:
{"goal":"string","tasks":[{"id":"string","type":"vocabulary|grammar|listening|speaking|writing|quiz","titleDari":"string","minutes":number,"instructionDari":"string"}]}
Use exactly 6 tasks and distribute time approximately across the six skills.`;
    const r=await client.responses.create({model:process.env.OPENAI_MODEL||"gpt-5",input:prompt});
    const clean=r.output_text.replace(/```json|```/g,"").trim();
    res.json(JSON.parse(clean));
  }catch(e){console.error(e);res.status(500).json({error:"Lesson generation failed",detail:e.message})}
}
