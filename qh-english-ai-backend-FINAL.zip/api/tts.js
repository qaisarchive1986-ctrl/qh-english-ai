import OpenAI from "openai";
import { cors } from "./_cors.js";

export default async function handler(req,res){
  if(cors(req,res)) return;
  if(req.method!=="POST") return res.status(405).json({error:"POST only"});
  try{
    const {text,voice="alloy"}=req.body||{};
    if(!text) return res.status(400).json({error:"text is required"});
    if(text.length>4096) return res.status(400).json({error:"text is too long"});
    if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const r=await client.audio.speech.create({model:"gpt-4o-mini-tts",voice,input:text,response_format:"mp3"});
    const buf=Buffer.from(await r.arrayBuffer());
    res.json({audio:buf.toString("base64"),mime:"audio/mpeg"});
  }catch(e){console.error(e);res.status(500).json({error:"Speech generation failed",detail:e.message})}
}
