const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const levels=[
["A1","مبتدی","الفبا، معرفی، جمله‌های بسیار ساده"],
["A2","پایه","زندگی روزمره و مکالمه ساده"],
["B1","متوسط","گفتگو، سفر، کار و متن"],
["B2","متوسط رو به بالا","مکالمه روان و نوشتار"],
["C1","پیشرفته","زبان آکادمیک و حرفه‌ای"],
["C2","تسلط","درک و تولید پیشرفته"]
];
const skills=[["🔤","Vocabulary","لغات و عبارت‌های کاربردی"],["🧩","Grammar","گرامر از پایه تا پیشرفته"],["🗣️","Speaking","مکالمه و پاسخ‌گویی"],["🎧","Listening","تمرین شنیداری"],["✍️","Writing","نوشتن و اصلاح متن"]];
let level=localStorage.getItem("qhLevel")||"A1",completed=Number(localStorage.getItem("qhCompleted")||0),mode="teacher";
function renderLevels(){$("#levels").innerHTML=levels.map(x=>`<div class="level ${x[0]===level?"selected":""}" data-l="${x[0]}"><b>${x[0]}</b><strong>${x[1]}</strong><small>${x[2]}</small></div>`).join("");$$(".level").forEach(e=>e.onclick=()=>{level=e.dataset.l;localStorage.setItem("qhLevel",level);renderLevels();updateProgress();addBot(`سطح شما به <b>${level}</b> تغییر کرد. عالی! حالا درس‌های مناسب همین سطح را تمرین می‌کنیم.`)})}
function renderSkills(){$("#skills").innerHTML=skills.map(x=>`<div class="skill"><div>${x[0]}</div><strong>${x[1]}</strong><span>${x[2]}</span><br><button class="outline practice">شروع تمرین</button></div>`).join("");$$(".practice").forEach((b,i)=>b.onclick=()=>{completed++;localStorage.setItem("qhCompleted",completed);updateProgress();addBot(`تمرین <b>${skills[i][1]}</b> انتخاب شد. ${skills[i][2]}<br><br>یک جمله انگلیسی بنویسید تا آن را بررسی کنم.`);location.hash="tutor"})}
function updateProgress(){let p=Math.min(100,completed*5);$("#percent").textContent=p+"%";$("#bar").style.width=p+"%";$("#levelTitle").textContent=level+" • "+levels.find(x=>x[0]===level)[1];$("#progressText").textContent=completed?`${completed} تمرین/فعالیت تکمیل شده است.`:"هنوز فعالیتی تکمیل نشده است."}
function addMsg(text,user=false){let d=document.createElement("div");d.className="msg "+(user?"user":"");d.innerHTML=`<div class="box"><small>${user?"شما":"QH English AI"}</small>${text}</div>`;$("#messages").appendChild(d);$("#messages").scrollTop=$("#messages").scrollHeight}
function addBot(x){addMsg(x)}
function answer(t){
 const x=t.toLowerCase();
 if(x.includes("hello")||x.includes("سلام"))return `<b>Hello = سلام</b> 👋<br>مثال: <b>Hello, my name is Sara.</b><br>یعنی: سلام، نام من سارا است.<br><br>تمرین: «من از افغانستان هستم» را به انگلیسی بنویسید.`;
 if(x.includes("صفر")||x.includes("شروع"))return `<b>درس ۱ — شروع از صفر</b> 🔤<br>الفبای انگلیسی 26 حرف دارد: A تا Z.<br><br><b>A = Apple</b> (سیب) 🍎<br><b>B = Book</b> (کتاب) 📘<br><br>تمرین: A, B, C, D, E را بنویسید.`;
 if(x.includes("present")||x.includes("گرامر"))return `<b>Present Simple — زمان حال ساده</b><br>برای عادت‌ها و کارهای تکراری است.<br><br>I work. = من کار می‌کنم.<br>You work. = تو کار می‌کنی.<br>She works. = او کار می‌کند.<br><br>نکته: با <b>he / she / it</b> معمولاً <b>s</b> می‌آید.<br><br>تمرین: «او هر روز انگلیسی می‌خواند.»`;
 if(x.includes("مکالمه")||x.includes("صحبت"))return `<b>Conversation 🗣️</b><br>Teacher: Hello! What is your name?<br><br>به انگلیسی جواب دهید: <b>My name is …</b>`;
 if(x.includes("معنی")||x.includes("ترجمه"))return `کلمه یا جمله انگلیسی را بفرستید؛ من <b>معنی دری، تلفظ، مثال و نکته گرامری</b> را توضیح می‌دهم.`;
 return `آفرین که تمرین می‌کنید! 😊<br>در حالت فعلی می‌توانید درباره <b>لغات، گرامر، مکالمه و درس‌های A1–C2</b> سؤال کنید.<br><br>سطح: <b>${level}</b> • حالت: <b>${mode}</b>`;
}
$("#form").onsubmit=e=>{e.preventDefault();let t=$("#input").value.trim();if(!t)return;addMsg(t,true);$("#input").value="";setTimeout(()=>addBot(answer(t)),220)};
$$(".chips button").forEach(b=>b.onclick=()=>{$("#input").value=b.textContent;$("#form").requestSubmit()});
$$(".tab").forEach(b=>b.onclick=()=>{$$(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");mode=b.dataset.mode;addBot(`حالت <b>${b.textContent}</b> فعال شد. تمرین خود را بفرستید.`)});
$("#clear").onclick=()=>{$("#messages").innerHTML="";welcome()};
$("#reset").onclick=()=>{if(confirm("پیشرفت این دستگاه پاک شود؟")){completed=0;localStorage.setItem("qhCompleted",0);updateProgress()}};
function welcome(){addBot(`سلام! 👋 من <b>QH English AI 2.0</b> هستم.<br>سطح فعلی شما <b>${level}</b> است.<br><br>می‌خواهید از صفر شروع کنیم یا مکالمه تمرین کنیم؟`)}
const qs=[
["Choose: I ___ a student.",["am","is","are","be"],0],
["“book” means:",["کتاب","خانه","آب","دوست"],0],
["She ___ every day.",["work","works","working","is work"],1],
["Past of “go” is:",["goed","gone","went","goes"],2],
["“Good morning” means:",["صبح بخیر","شب بخیر","خداحافظ","متشکرم"],0],
["Choose the correct plural:",["childs","children","childes","childrens"],1],
["I have lived here ___ 2020.",["for","since","at","on"],1],
["If I had time, I ___ travel.",["will","would","am","can"],1],
["Synonym of “rapid”:",["slow","quick","late","weak"],1],
["She suggested ___ earlier.",["leave","to leave","leaving","left"],2]
];
let qi=0,sc=0;
function renderPlacement(){if(qi>=qs.length){let p=Math.round(sc/qs.length*100);let suggested=p<40?"A1–A2":p<70?"B1–B2":"C1–C2";$("#placement").innerHTML=`<h3>نتیجه آماده است 🎉</h3><p>امتیاز: <b>${sc}/${qs.length} (${p}%)</b></p><p>سطح پیشنهادی: <b>${suggested}</b></p><button class="btn" id="again">آزمون دوباره</button>`;$("#again").onclick=()=>{qi=0;sc=0;renderPlacement()};return}let q=qs[qi];$("#placement").innerHTML=`<div class="qtitle"><b>${qi+1}/${qs.length}</b> — ${q[0]}</div><div class="answers">${q[1].map((a,i)=>`<button class="answer" data-i="${i}">${a}</button>`).join("")}</div>`;$$(".answer").forEach(b=>b.onclick=()=>{let ok=+b.dataset.i===q[2];if(ok){sc++;b.classList.add("good")}else b.classList.add("bad");$$(".answer").forEach(a=>a.disabled=true);setTimeout(()=>{qi++;renderPlacement()},400)})}
let deferred;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferred=e;$("#installBtn").hidden=false});
$("#installBtn").onclick=async()=>{if(deferred){deferred.prompt();await deferred.userChoice;deferred=null;$("#installBtn").hidden=true}};
renderLevels();renderSkills();updateProgress();renderPlacement();welcome();