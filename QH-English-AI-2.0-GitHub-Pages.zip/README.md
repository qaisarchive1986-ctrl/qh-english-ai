# QH English AI 2.0

نسخهٔ پیشرفتهٔ وب‌اپ آموزشی انگلیسی به زبان دری.

## امکانات
- CEFR: A1 تا C2
- Vocabulary / Grammar / Speaking / Listening / Writing
- چت آموزشی به دری
- حالت‌های معلم، مکالمه، گرامر، لغات و آزمون
- آزمون تعیین سطح ۱۰ سؤالی
- سیستم پیشرفت با LocalStorage
- PWA / قابلیت نصب در مرورگرهای پشتیبان
- طراحی واکنش‌گرا برای Android و Desktop
- GitHub Pages ready

## انتشار
فایل‌ها را در ریشهٔ repository قرار دهید و از:
Settings → Pages → Deploy from a branch → main → /(root)
استفاده کنید.

## AI واقعی
نسخهٔ 2.0 هستهٔ آموزشی محلی دارد و بدون API اجرا می‌شود. برای مدل زبانی واقعی، API باید در یک backend امن قرار گیرد. کلید API را هرگز داخل JavaScript عمومی GitHub Pages قرار ندهید.
